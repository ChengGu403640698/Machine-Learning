def parameters():
    k = 30  # knn neighbors
    h = 0.3  # kde windowsize / radius
    return h, k
